#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>


#define ERR(source) \
    (fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), perror(source), kill(0, SIGKILL), exit(EXIT_FAILURE))

volatile sig_atomic_t task_counter = 0; // Tracks the number of SIGUSR1 signals received
volatile sig_atomic_t last_signal_sender = 0; // PID of the last student that raised a hand
volatile sig_atomic_t sigusr1_flag = 0;
volatile sig_atomic_t sigusr2_flag = 0;

void sethandler(void (*f)(int, siginfo_t *, void *), int sigNo) //set signal handler f for signal sigNo
{
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction)); //set bytes in the memory for act
    act.sa_sigaction = f;
    act.sa_flags = SA_SIGINFO; // To access siginfo_t
    if(-1 == sigaction(sigNo, &act, NULL)) //The sigaction() function allows the calling process to specify  the  action to be associated with a specific signal
    {
        ERR("sigaction");
    }
}

void sigchld_handler(int sig, siginfo_t *info, void *context) //handles SIGCHLD(sent when child process terminates)
{
    pid_t pid;
    for(;;)
    {
        pid = waitpid(0, NULL, WNOHANG); //checks if children terminated 
        if(pid == 0)
        {
            return;
        }
        if(pid <= 0)
        {
            if(errno == ECHILD) //no more children exist
            {
                return;
            }
            ERR("waitpid");
        }
    }
}

// Handles SIGUSR1 and identifies the sender PID
void sigusr1_handler(int sig, siginfo_t *info, void *context)
{
    sigusr1_flag = 1;
    last_signal_sender = info->si_pid; // Store the sender's PID
    task_counter++;
    printf("[TEACHER] Received SIGUSR1 from Student[%d]. Total parts reported: %d\n", last_signal_sender, task_counter);
}

void sigusr2_handler(int sig, siginfo_t *info, void *context) 
{
    sigusr2_flag = 1; // Mark that SIGUSR2 was received
}

void child_work_stage1(int i, int probability)
{
    srand(time(NULL) * getpid());
    printf("Student [%d, %d] started with probability %d\n", i, getpid(), probability);
}

void child_work_stage2(int i, int p, int probability, int t)
{
    int issue_chance, sleep_time = t * 100; //each part takes t*100 ms

    srand(time(NULL) * getpid());

    printf("Student [%d, %d] has started doing task!\n", i, getpid());
    
    int issue_count = 0;

    for(int part = 1; part <= p; part++)
    {
        printf("Student[%d,%d] is starting doing part %d of %d!\n", i, getpid(), part, p);

        for(int j = 0; j < t; j++) //simulate task time for the part( while doing the part of the task student might encounter an issue)
        {
            usleep(100000);//sleep for 100 ms, because: for every 100 ms of doing a task by a student, there is a given chance out of 100 that the student will need an additional 50 ms

            issue_chance = rand() % 101; 

            if(issue_chance < probability)
            {
                issue_count++;
                printf("Student[%d,%d] has issue (%d) doing task!\n", i, getpid(), issue_count);
                usleep(50000); // Additional 50 ms delay for the issue
            }
        }

        //When a student finishes some part of the task, they raise a hand (sends SIGUSR1 signal to the teacher) and wait for the teacher to check it
        printf("Student[%d,%d] has finished part %d of %d!\n", i, getpid(), part, p);
        if(kill(getppid(), SIGUSR1)) 
        {
            ERR("kill");
        }
    }
}

void child_work_stage3(int i, int p, int probability, int t)
{
    int issue_chance, issue_count = 0;

    srand(getpid());
    printf("Student [%d, %d] has started doing task!\n", i, getpid());

    sethandler(sigusr2_handler, SIGUSR2);

    for (int part = 1; part <= p; part++) 
    {
        printf("Student[%d,%d] is starting part %d of %d!\n", i, getpid(), part, p);

        for (int j = 0; j < t; j++) {
            usleep(100000); // Simulate 100ms of work

            issue_chance = rand() % 101;
            if (issue_chance < probability) 
            {
                issue_count++;
                printf("Student[%d,%d] encountered an issue (%d) doing task!\n", i, getpid(), issue_count);
                usleep(50000); // Additional 50ms delay for issue
            }
        }

        printf("Student[%d,%d] finished part %d of %d. Raising hand.\n", i, getpid(), part, p);

        // Raise hand (send SIGUSR1 to teacher)
        if (kill(getppid(), SIGUSR1)) 
        {
            ERR("kill");
        }

        // Wait for teacher's confirmation (SIGUSR2)
        while (!sigusr2_flag) 
        {
            pause();
        }

        sigusr2_flag = 0; // Reset flag for next part
        printf("Student[%d, %d] received confirmation. Proceeding to next part: %d.\n", i, getpid(), part + 1);
    }

    printf("Student[%d,%d] completed all parts!\n", i, getpid());
}

void parent_work_stage1_2(int n)
{
    int status;
    pid_t pid;

    while(n > 0)
    {
        pid = wait(&status);
        if(pid > 0)
        {
            n--;
        }
        else
        {
            if(errno == ECHILD) break;
            if(errno == EINTR) continue;
            ERR("wait");
        }
    }

    printf("[PARENT] process terminates\n");
}

void parent_work_stage3(int n)
{
    while (n > 0) 
    {
        if (!sigusr1_flag) 
        {
            pause(); // Wait for SIGUSR1 (a student raising a hand)
        }

        if (sigusr1_flag) 
        {
            sigusr1_flag = 0; // Reset the flag

            // Respond to the student with SIGUSR2
            if (kill(last_signal_sender, SIGUSR2)) ERR("kill");
            printf("[TEACHER] Confirmed Student[%d]'s progress. Sent SIGUSR2.\n", last_signal_sender);

        }

        // Check if any children terminated (optional cleanup)
        sigchld_handler(0, NULL, NULL);
        sigusr1_flag = 0;
    }

    printf("[TEACHER] All students have completed their tasks.\n");
}

void create_children(int n, int p, int probabilities[], int t)
{
    pid_t s;
    for (int i = 0; i < n; i++)
    {
        if ((s = fork()) < 0)
            ERR("Fork:");
        if (!s)
        {
            child_work_stage3(i, p, probabilities[i], t);
            exit(EXIT_SUCCESS);
        }
    }
}

void usage(char *name) 
{
    fprintf(stderr, "USAGE: p t probabilities[n] l\n");
    fprintf(stderr, "n - number of students\n");
    fprintf(stderr, "p - number of parts into which the task was divided\n");
    fprintf(stderr, "t - time it taskes to solve the task\n");
    fprintf(stderr, "probabilities[n] - each number determines each students probability of having some issue during classes.\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    if(argc < 4)
    {
        usage(argv[0]);
    }

    int p = atoi(argv[1]);
    int t = atoi(argv[2]);
    int n = argc - 3;
    int probabilities[n];

    if(p < 1 || p > 10 || t <= 1 || t > 10)
    {
        usage(argv[0]);
    }

    for(int i = 0; i < n; i++)
    {
        probabilities[i] = atoi(argv[3 + i]);

        if(probabilities[i] < 0 || probabilities[i] > 100)
        {
            usage(argv[0]);
        }
    }

    printf("PARENT creating %d children...\n", n);

    sethandler(sigusr1_handler, SIGUSR1);
    sethandler(sigchld_handler, SIGCHLD);

    create_children(n, p, probabilities, t);

    parent_work_stage3(n);

    while (wait(NULL) > 0 || errno == EINTR)
        ; // Wait for all children to terminate

    printf("PARENT: All children have completed their tasks. Terminating...\n");
    return EXIT_SUCCESS;
}