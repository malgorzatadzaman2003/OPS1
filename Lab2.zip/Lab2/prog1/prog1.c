#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

//macro ERR also kills all processes in the current process group to ensure cleanup
#define ERR(source) \
    (fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), perror(source), kill(0, SIGKILL), exit(EXIT_FAILURE))

void child_work(int i)
{
    srand(time(NULL) * getpid()); //random id generator for children
    int t = 5 + rand() % (10 - 5 + 1); //generate random [5-10]s time - t
    sleep(t); //waits t seconds and terminates
    printf("PROCESS with pid %d terminates\n", getpid());
}

void create_children(int n)
{
    pid_t s;
    for(n--; n >= 0; n--)
    {
        if((s = fork()) < 0)
        {
            ERR("fork");
        }
        if(!s) //if frok returns 0 then this is a child process hence we need to do child_work
        {
            child_work(n);
            exit(EXIT_SUCCESS);
        }
        //if fork() returns > 0, then this is parent process, and it continues looping
    }
}

void usage(char *name)
{
    fprintf(stderr, "USAGE: %s 0<n\n", name);
    exit(EXIT_FAILURE);
}

//first part - after running the program, command line returns immediately while processes are still working
/* int main(int argc, char **argv)
{
    int n;

    if(argc < 2)
    {
        usage(argv[0]);
    }

    n = atoi(argv[1]);
    if(n <= 0)
    {
        usage(argv[0]);
    }

    create_children(n);
    return EXIT_SUCCESS;
} */

//second part 
int main(int argc, char **argv)
{
    int n;

    if(argc < 2)
    {
        usage(argv[0]);
    }

    n = atoi(argv[1]); //geting the firts argument as the number of processes to be created 
    if(n <= 0)
    {
        usage(argv[0]);
    }

    create_children(n); //create n child processes

    while(n > 0) //continue until all child processes have terminated
    {
        sleep(3); //sleep 3s before checking the status of child processes 
        pid_t pid;
        for(;;)
        {
            pid = waitpid(0, NULL, WNOHANG); //non-blocking check for terminated children, 0 as pid because we want to wait for any child process 
            if(pid > 0) //if child has terminated 
            {
                n--; //we decrease the amount of active child porcesses
            }
            if(0 == pid) //if no children have terminated 
            {
                break;
            }
            if(0 >= pid)
            {
                if(ECHILD == errno) //no more child processes exists
                {
                    break;
                }
                ERR("waitpid");
            }
        }
        printf("PARENT: %d processes remain\n", n);
    }
    return EXIT_SUCCESS;
} 

/* 

for n = 3 we have 
Parent (n=3)
├── Child 1 (n=2)
│   ├── Grandchild 1 (n=1)
│   │   └── Great-Grandchild 1 (n=0)
│   └── Grandchild 2 (n=0)
├── Child 2 (n=1)
│   └── Grandchild 3 (n=0)
└── Child 3 (n=0) 

*/
