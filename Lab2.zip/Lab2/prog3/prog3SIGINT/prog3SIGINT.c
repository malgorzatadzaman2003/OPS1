#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>


#define ERR(source) \
    (fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), perror(source), kill(0, SIGKILL), exit(EXIT_FAILURE))

volatile __sig_atomic_t last_signal = 0; //the last signal received

void sethandler(void (*f)(int), int sigNo) //set signal handler f for signal sigNo
{
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction)); //set bytes in the memory for act
    act.sa_handler = f;
    if(-1 == sigaction(sigNo, &act, NULL)) //The sigaction() function allows the calling process to specify  the  action to be associated with a specific signal
    {
        ERR("sigaction");
    }
}

void sig_handler(int sig) //handles signals such as SIGUSR1 and SIGUSR2 
{
    last_signal = sig;
}

void sigchld_handler(int sig) //handles SIGCHLD(sent when child process terminates)
{
    pid_t pid;
    for(;;)
    {
        pid = waitpid(0, NULL, WNOHANG); //checks if children terminated 
        if(pid == 0)
        {
            return;
        }
        if(pid <= 0)
        {
            if(errno == ECHILD) //no more children exist
            {
                return;
            }
            ERR("waitpid");
        }
    }
}

void child_work(int m, int p)
{
    int count = 0; 
    struct timespec t = {0, m * 10000}; //time delay: m milliseconds in nanoseconds

    while(1)
    {
        for(int i = 0; i < p; i++) //sendind SIGUSR1 p times then switch to SIGUSR2
        {
            nanosleep(&t, NULL); //every m microseconds child process sends a SIGUSR1 signal to the parent

            if(kill(getppid(), SIGUSR1))
            {
                ERR("kill");
            }
        }

        nanosleep(&t, NULL);

        if(kill(getppid(), SIGUSR2)) //Every p-th signal is changed to SIGUSR2
        {
            ERR("kill");
        }

        count++; //Child process also counts the amount of SIGUSR2 sent.

        printf("[%d] sent %d SIGUSR2\n", getpid(), count);
    }
}

void parent_work(sigset_t oldmask)
{
    int count = 0;

    while(1)
    {
        last_signal = 0;

        while(last_signal != SIGUSR2) //wait until SIGUSR2 is received
        {
            sigsuspend(&oldmask); //temporarily unblocks signals
        }

        count++;

        printf("[PARENT] received %d SIGUSR2\n", count);
    }
}


void usage(char *name)
{
    fprintf(stderr, "USAGE: %s m  p\n", name);
    fprintf(stderr,
            "m - number of 1/1000 milliseconds between signals [1,999], "
            "i.e. one milisecond maximum\n");
    fprintf(stderr, "p - after p SIGUSR1 send one SIGUSER2  [1,999]\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    int m,p; //Program takes 2 positional parameters (m.p)

    if(argc != 3)
    {
        usage(argv[0]);
    }

    m = atoi(argv[1]);
    p = atoi(argv[2]);

    if(m <= 0 || m > 999 || p <= 0 || p > 999)
    {
        usage(argv[0]);
    }

    sethandler(sigchld_handler, SIGCHLD);
    sethandler(sig_handler, SIGUSR1);
    sethandler(sig_handler, SIGUSR2);

    sigset_t mask, oldmask;

    sigemptyset(&mask);
    sigaddset(&mask, SIGUSR1);
    sigaddset(&mask, SIGUSR2);

    sigprocmask(SIG_BLOCK, &mask, &oldmask); //block SIGUSR1 and SIGUSR2

    pid_t pid;

    if((pid = fork()) < 0) //create child process
    {
        ERR("fork");
    }

    if(pid == 0)
    {
        child_work(m,p);
    }
    else
    {
        parent_work(oldmask);
        while(wait(NULL) > 0)
        {
            ;
        }
    }

    sigprocmask(SIG_UNBLOCK, &mask, NULL); //unblock signals

    return EXIT_SUCCESS;
}