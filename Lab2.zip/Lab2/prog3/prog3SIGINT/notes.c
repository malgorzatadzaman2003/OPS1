#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>


#define ERR(source) \
    (fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), perror(source), kill(0, SIGKILL), exit(EXIT_FAILURE))

volatile __sig_atomic_t last_signal = 0; //the last signal received

void sethandler(void (*f)(int), int sigNo) //set signal handler f for signal sigNo
{
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction)); //set bytes in the memory for act
    act.sa_handler = f;
    if(-1 == sigaction(sigNo, &act, NULL)) //The sigaction() function allows the calling process to specify  the  action to be associated with a specific signal
    {
        ERR("sigaction");
    }
}

void sig_handler(int sig) //handles signals such as SIGUSR1 and SIGUSR2 
{
    last_signal = sig;
}

void sigchld_handler(int sig) //handles SIGCHLD(sent when child process terminates)
{
    pid_t pid;
    for(;;)
    {
        pid = waitpid(0, NULL, WNOHANG); //checks if children terminated 
        if(pid == 0)
        {
            return;
        }
        if(pid <= 0)
        {
            if(errno == ECHILD) //no more children exist
            {
                return;
            }
            ERR("waitpid");
        }
    }
}

void child_work()
{
    int t,tt; //t - time delay, l - This loop iterates l times
    int l = 30;

    srand(getpid()); ////initialize random seed based on process ID

    t = rand() % 101 + 100; //Each child process has to generate random number of seconds “s” form the range of [100-200] milliseconds
    
    printf("Child %d: Random delay = %d ms\n", getpid(), t);

    for (int i = 0; i < 30; i++) 
    {
        usleep(t / 1000);  // Sleep for s milliseconds

        if (kill(getppid(), SIGUSR1) != 0) 
        {
            ERR("kill");
        }

        printf("*");
    }
}

void parent_work(sigset_t oldmask)
{
    int count = 0;

    while(1)
    {
        last_signal = 0;

        while(last_signal != SIGUSR1) //wait until SIGIT interrupts
        {
            sigsuspend(&oldmask); //temporarily unblocks signals
        }

        count++;

        printf("[PARENT] received %d SIGUSR1\n", count);
    }
}

void usage(char *name) 
{
    fprintf(stderr, "Usage: %s n\n", name);
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    int n;

    if(argc != 2)
    {
        usage(argv[0]);
    }

    n = atoi(argv[1]);

    if(n <= 0)
    {
        usage(argv[0]);
    }

    sethandler(sig_handler, SIGUSR1);
    
    for (int i = 0; i < n; i++) 
    {
        pid_t pid = fork();
        
        if (pid < 0) 
        {
            ERR("fork");
            return EXIT_FAILURE;
        }

        if (pid == 0) 
        {
            // Child process
            child_work();
            exit(0);  // Child exits
        }
    }

    return EXIT_SUCCESS;
}