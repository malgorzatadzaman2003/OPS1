#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>


#define ERR(source) \
    (fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), perror(source), kill(0, SIGKILL), exit(EXIT_FAILURE))

volatile __sig_atomic_t last_signal = 0; //the last signal received 

void sethandler(void (*f)(int), int sigNo) //set signal handler f for signal sigNo
{
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction)); //set bytes in the memory for act
    act.sa_handler = f;
    if(-1 == sigaction(sigNo, &act, NULL)) //The sigaction() function allows the calling process to specify  the  action to be associated with a specific signal
    {
        ERR("sigaction");
    }
}

void sig_handler(int sig) //handles signals such as SIGUSR1 and SIGUSR2 
{
    printf("[%d] received signal %d\n", getpid(), sig);
    last_signal = sig;
}

void sigchld_handler(int sig) //handles SIGCHLD(sent when child process terminates)
{
    pid_t pid;
    for(;;)
    {
        pid = waitpid(0, NULL, WNOHANG); //checks if children terminated 
        if(pid == 0)
        {
            return;
        }
        if(pid <= 0)
        {
            if(errno == ECHILD) //no more children exist
            {
                return;
            }
            ERR("waitpid");
        }
    }
}

void child_work(int l)
{
    int t,tt; //t - time delay, l - This loop iterates l times

    srand(getpid()); ////initialize random seed based on process ID

    t = rand() % 6 +5; //Each sub-process determines its own random time delay [5,10] sec

    while(l-- > 0)
    {
        for(tt = t; tt > 0; tt = sleep(tt)) ///and in a loop sleeps this time 
        {
            ;
        }
        
        if(last_signal == SIGUSR1)
        {
            printf("SUCCESS [%d]\n", getpid()); //and prints SUCCESS on the stdout if the last signal received was SIGUSR1
        }
        else if(last_signal == SIGUSR2)
        {
            printf("FAILURE [%d]\n", getpid()); //or FAILURE if it was SIGUSER2
        }
    }
    printf("[%d] TERMINATES\n", getpid());
}

void parent_work(int k, int p, int l)
{
    //Parent process sends sequentially SIGUSR1 and SIGUSR2 to all sub-processes in a loop with delays of k and p seconds
    struct timespec tk = {k,0};
    struct timespec tp = {p,0};

    sethandler(sig_handler, SIGALRM);

    alarm(l * 10); //schedules the signal to be delivered to the process, to ensure that the parent process doesn't run indefinely

    while(last_signal != SIGALRM) //when SIGLALR is received the loop ends
    {
        nanosleep(&tk, NULL); //k sec. before SIGUSR1

        if(kill(0, SIGUSR1) < 0) //sending SIGUSR1, Kill function is invoked with 0 pid, means it is sending signal to whole group of processes
        {
            ERR("kill");
        }

        nanosleep(&tp, NULL); //and p sec. before SIGUSR2

        if(kill(0, SIGUSR2) < 0) //sending SIGUSR2
        {
            ERR("kill");
        }
    }
    printf("[PARENT] TERMINATES\n"); //Parent process terminates after all its sub-processes
}

void create_children(int n, int l)
{
    while(n-- > 0) ////Program creates n sub-processe
    {
        switch(fork())
        {
            case 0:
                sethandler(sig_handler, SIGUSR1);
                sethandler(sig_handler, SIGUSR2);
                child_work(l);
                exit(EXIT_SUCCESS);
            case -1:
                perror("fork");
                exit(EXIT_FAILURE);
        }
    }
}

void usage(void)
{
    fprintf(stderr, "USAGE: signals n k p l\n");
    fprintf(stderr, "n - number of children\n");
    fprintf(stderr, "k - Interval before SIGUSR1\n");
    fprintf(stderr, "p - Interval before SIGUSR2\n");
    fprintf(stderr, "l - lifetime of child in cycles\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    int n,k,p,l; //Program takes 4 positional parameters (n,k,p,l)

    if(argc != 5)
    {
        usage();
    }

    n = atoi(argv[1]);
    k = atoi(argv[2]);
    p = atoi(argv[3]);
    l = atoi(argv[4]);

    if(n <= 0 || k <= 0 || p <= 0 || l <= 0)
    {
        usage();
    }

    sethandler(sigchld_handler, SIGCHLD);
    sethandler(SIG_IGN, SIGUSR1);
    sethandler(SIG_IGN, SIGUSR2);

    create_children(n, l);

    parent_work(k, p, l);

    while(wait(NULL) > 0)
    {
        ;
    }

    return EXIT_SUCCESS;
}