#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>


#define ERR(source) \
    (fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), perror(source), kill(0, SIGKILL), exit(EXIT_FAILURE))

volatile sig_atomic_t sig_count = 0; //counter for received SIGUSR1

void sethandler(void (*f)(int), int sigNo) //set signal handler f for signal sigNo
{
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction)); //set bytes in the memory for act
    act.sa_handler = f;
    if(-1 == sigaction(sigNo, &act, NULL)) //The sigaction() function allows the calling process to specify  the  action to be associated with a specific signal
    {
        ERR("sigaction");
    }
}

void sig_handler(int sig) //handles signals such as SIGUSR1
{
    sig_count++;
}

void child_work(int m)
{
    struct timespec t = {0, m * 10000}; //time delay: m milliseconds in nanoseconds
    sethandler(SIG_DFL, SIGUSR1); // Reset SIGUSR1 handling to default.
    /*  Purpose: The child process resets the SIGUSR1 handler to its default behavior.
        The default action for SIGUSR1 (when not explicitly handled) is to do nothing and continue execution.
        Why reset it? The child process is sending the signal, not receiving it. Therefore:

        The child does not need to count SIGUSR1 signals like the parent.
        By resetting the handler to default (SIG_DFL), the child avoids unnecessary signal handling overhead.
        Any unintended signals will not trigger custom behavior. */
    while(1)
    {
        nanosleep(&t, NULL);

        if(kill(getppid(), SIGUSR1)) //send SIGUSR1 to the parent process
        {
            ERR("kill");
        }
    }
}

ssize_t bulk_read(int fd, char *buf, size_t count)
{
    ssize_t c;
    ssize_t len = 0;
    do
    {
        c = TEMP_FAILURE_RETRY(read(fd, buf, count));

        if(c < 0)
        {
            return c; //if error, return the error
        }
        if(c == 0)
        {
            return len; //EOF
        }

        buf += c;
        len += c;
        count -= c;
    } while (count > 0);
    
    return len;
}

ssize_t bulk_write(int fd, char *buf, size_t count)
{
    ssize_t c;
    ssize_t len = 0;
    do
    {
        c = TEMP_FAILURE_RETRY(write(fd, buf, count));

        if(c < 0)
        {
            return c; //if error, return the error
        }

        buf += c;
        len += c;
        count -= c;
    } while (count > 0);
    
    return len;
}

void parent_work(int b, int s, char *name)
{
    int i, in, out;
    ssize_t count;
    char *buf = malloc(s);

    if(!buf)
    {
        ERR("malloc");
    }

    if((out = TEMP_FAILURE_RETRY(open(name, O_WRONLY | O_CREAT | O_TRUNC | O_APPEND, 0777))) < 0)
    {
        ERR("open");
    }

    if((in = TEMP_FAILURE_RETRY(open("/dev/urandom", O_RDONLY))) < 0)
    {
        ERR("open");
    }
        
    for(i = 0; i < b; i++) 
    {
        if((count = bulk_read(in, buf, s)) < 0) //reads reads b blocks of size s from /dev/urandom 
        {
            ERR("read");
        }

        if((count = bulk_write(out, buf, count)) < 0) //writes the data to the "name" file 
        {
            ERR("write");
        }
        
        if(TEMP_FAILURE_RETRY(fprintf(stderr, "Block of %ld bytes transfered. Signals RX:%d\n", count, sig_count)) < 0) //prints the transferred block size and the number of received signals
        {
            ERR("fprintf");
        }
    }

    if(TEMP_FAILURE_RETRY(close(in)))
    {
        ERR("close");
    }
        
    if (TEMP_FAILURE_RETRY(close(out)))
    {
        ERR("close");
    }

    free(buf);

    if (kill(0, SIGUSR1)) //send SIGUSR1 to all processes in the group
    {
        ERR("kill");
    }
}


void usage(char *name)
{
        fprintf(stderr, "USAGE: %s m b s \n", name);
    fprintf(stderr,
            "m - number of 1/1000 milliseconds between signals [1,999], "
            "i.e. one milisecond maximum\n");
    fprintf(stderr, "b - number of blocks [1,999]\n");
    fprintf(stderr, "s - size of of blocks [1,999] in MB\n");
    fprintf(stderr, "name of the output file\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    int m,b,s; //Program takes 4 positional parameters (m,b,s,name)
    char *name;

    if(argc != 5)
    {
        usage(argv[0]);
    }

    m = atoi(argv[1]);
    b = atoi(argv[2]);
    s = atoi(argv[3]);
    name = argv[4];

    if (m <= 0 || m > 999 || b <= 0 || b > 999 || s <= 0 || s > 999)
    {
        usage(argv[0]);
    }

    sethandler(sig_handler, SIGUSR1); //The parent process needs to handle SIGUSR1 signals sent by the child. The sig_handler function increments the sig_count variable every time the parent receives a SIGUSR1 signal. Without this line, the parent process would not know what to do with SIGUSR1, and the default behavior would occur, which is to terminate the process.

    pid_t pid;

    if((pid = fork()) < 0) //create child process
    {
        ERR("fork");
    }

    if(pid == 0)
    {
        child_work(m);
    }
    else
    {
        parent_work(b, s * 1024 * 1024, name);
        while(wait(NULL) > 0)
        {
            ;
        }
    }

    return EXIT_SUCCESS;
}