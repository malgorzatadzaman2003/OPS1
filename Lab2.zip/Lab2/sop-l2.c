#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), kill(0, SIGKILL), exit(EXIT_FAILURE))

ssize_t bulk_read(int fd, char* buf, size_t count)
{
    ssize_t c;
    ssize_t len = 0;
    do
    {
        c = TEMP_FAILURE_RETRY(read(fd, buf, count));
        if (c < 0)
            return c;
        if (c == 0)
            return len;  // EOF
        buf += c;
        len += c;
        count -= c;
    } while (count > 0);
    return len;
}

ssize_t bulk_write(int fd, char* buf, size_t count)
{
    ssize_t c;
    ssize_t len = 0;
    do
    {
        c = TEMP_FAILURE_RETRY(write(fd, buf, count));
        if (c < 0)
            return c;
        buf += c;
        len += c;
        count -= c;
    } while (count > 0);
    return len;
}

volatile sig_atomic_t sigusr1_received = 0;

void sethandler(void (*f)(int), int sigNo)
{
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction));
    act.sa_handler = f;
    if (-1 == sigaction(sigNo, &act, NULL))
    {
        ERR("sigaction");
    }
}

void sigusr1_handler(int sig)
{
    sigusr1_received = 1;
}

void child_processing_fragment(char *fragment, int fragment_size, char* file, int child_number)
{
    char *out_file = malloc(strlen(file) + 10);  // Extra space for the child number and suffix
    if (!out_file)
    {
        ERR("malloc for out_file");
    }

    snprintf(out_file, strlen(file) + 10, "%s-%d", file, child_number);

    // Debugging print to check the generated output file name
    printf("Output file: %s\n", out_file);

    int out_fd = open(out_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out_fd < 0)
    {
        ERR("open");
    }

    for (int i = 0; i < fragment_size; i++)
    {
        if (i % 2 == 0 && fragment[i] >= 'a' && fragment[i] <= 'z')
        {
            fragment[i] -= 32;
        }
        else if (i % 2 == 0 && fragment[i] >= 'A' && fragment[i] <= 'Z')
        {
            fragment[i] += 32;
        }

        if (bulk_write(out_fd, &fragment[i], 1) < 0)
        {
            ERR("bulk_write");
        }

        usleep(250000);
    }

    if (close(out_fd) < 0)
    {
        ERR("close");
    }

    free(out_file);
}

void child_work(char* fragment, int fragment_size, char* file, int child_number)
{
    srand(time(NULL) * getpid()); // random id generator for children

    sethandler(sigusr1_handler, SIGUSR1); // Set signal handler

    while (!sigusr1_received) // wait until SIGUSR1 is received
    {
        pause(); // temporarily unblocks signals - stage2
    }

    //printf("PID: %d, Fragment: %.*s\n", getpid(), size, fragment);
    child_processing_fragment(fragment, fragment_size, file, child_number);
    exit(EXIT_SUCCESS);
}

void parent_work(char* file, int n)
{
    int fd = open(file, O_RDONLY);
    if (fd < 0)
    {
        perror("open");
        printf("File: %s\n", file); // Debug: show file name causing the error
        ERR("open");
    }

    struct stat st;
    if (fstat(fd, &st) < 0) ERR("fstat");
    size_t file_size = st.st_size;

    char *buf = malloc(file_size);
    if (!buf)
    {
        ERR("malloc");
    }

    int length = bulk_read(fd, buf, file_size);

    if (close(fd) < 0)
    {
        ERR("close");
    }

    int child_fragment_size = length / n;
    pid_t children[n];

    for (int i = 0; i < n; i++)
    {
        pid_t pid = fork();

        if (pid < 0)
        {
            ERR("fork");
        }

        if (pid == 0)
        {
            int start = i * child_fragment_size;
            int size = (i == n - 1) ? length - start : child_fragment_size;
            child_work(buf + start, size, file, i + 1);
        }

        children[i] = pid;
    }

    sleep(1); // Give children time to pause()

    for (int i = 0; i < n; i++)
    {
        if (kill(children[i], SIGUSR1) < 0)
        {
            ERR("kill");
        }
    }

    while (wait(NULL) > 0)
    {
        ;
    }

    free(buf);  // Free the allocated memory here

    printf("All processes terminated.\n");
}

void usage(int argc, char* argv[])
{
    printf("%s n f \n", argv[0]);
    printf("\tf - file to be processed\n");
    printf("\t0 < n < 10 - number of child processes\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char* argv[])
{
    char *file;
    int n;

    if (argc != 3)
    {
        usage(argc, argv);
    }

    file = argv[1];
    n = atoi(argv[2]);

    if (n <= 0 || n >= 10)
    {
        usage(argc, argv);
    }

    parent_work(file, n);

    return EXIT_SUCCESS;
}