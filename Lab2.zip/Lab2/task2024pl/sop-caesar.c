#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), kill(0, SIGKILL), exit(EXIT_FAILURE))

volatile sig_atomic_t sigusr1_received = 0;  // Signal flag
volatile sig_atomic_t sigint_received = 0;   // SIGINT flag

// Function to handle SIGINT
void sigint_handler(int sig) 
{
    sigint_received = 1;
}

// Function to handle SIGUSR1
void sigusr1_handler(int sig) 
{
    sigusr1_received = 1;
}

ssize_t bulk_read(int fd, char* buf, size_t count) 
{
    ssize_t c;
    ssize_t len = 0;
    do {
        c = TEMP_FAILURE_RETRY(read(fd, buf, count));
        if (c < 0) return c;
        if (c == 0) return len;  // EOF
        buf += c;
        len += c;
        count -= c;
    } while (count > 0);
    return len;
}

ssize_t bulk_write(int fd, char* buf, size_t count) 
{
    ssize_t c;
    ssize_t len = 0;
    do {
        c = TEMP_FAILURE_RETRY(write(fd, buf, count));
        if (c < 0) return c;
        buf += c;
        len += c;
        count -= c;
    } while (count > 0);
    return len;
}

void sethandler(void (*f)(int), int sigNo) 
{
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction));
    act.sa_handler = f;
    if (-1 == sigaction(sigNo, &act, NULL)) ERR("sigaction");
}

void caesar_cipher(char *buffer, size_t size) 
{
    for (size_t i = 0; i < size; i++) 
    {
        if (buffer[i] >= 'a' && buffer[i] <= 'z') 
        {
            buffer[i] = 'a' + (buffer[i] - 'a' + 3) % 26;
        }
    }
}

void sleep_with_interrupt_handling(unsigned int seconds) 
{
    struct timespec req = {.tv_sec = seconds, .tv_nsec = 0};
    while (nanosleep(&req, &req) == -1) 
    {
        if (errno != EINTR) 
        {
            ERR("nanosleep");
        }
    }
}

void child_processing_fragment(char *fragment, int fragment_size, char* file, int child_number) 
{
    size_t out_file_len = strlen(file) + 10;
    char *out_file = malloc(out_file_len);
    if (!out_file) 
    {
        ERR("malloc for out_file");
    }

    snprintf(out_file, out_file_len, "%s-%d", file, child_number);
    printf("Output file: %s\n", out_file);

    sethandler(sigint_handler, SIGINT);

    int out_fd = open(out_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out_fd < 0) 
    {
        ERR("open");
    }

    caesar_cipher(fragment, fragment_size);
    if (bulk_write(out_fd, fragment, fragment_size) < 0) 
    {
        ERR("bulk_write");
    }

    for (int i = 0; i < fragment_size; i++) 
    {
        sleep_with_interrupt_handling(0.1);  // Sleep for 0.1 seconds
    }

    if (sigint_received) 
    {
        printf("CHILD [%d] received SIGINT, closing describtors and sending SIGINT to parent.\n", getpid());
        if (close(out_fd) < 0) 
        {
            ERR("close");
        }

        if (kill(0, SIGINT) < 0) 
        {
            ERR("kill");
        }

        exit(EXIT_SUCCESS);
    }

    free(out_file);
}

void child_work(char* fragment, int fragment_size, char* file, int child_number) 
{
    srand(time(NULL) * getpid());
    sethandler(sigusr1_handler, SIGUSR1);  // Set SIGUSR1 handler
    sethandler(sigint_handler, SIGINT);    // Set SIGINT handler

    while (!sigusr1_received) 
    {
        pause();  // Temporarily unblocks signals
    }

    child_processing_fragment(fragment, fragment_size, file, child_number);

    exit(EXIT_SUCCESS);
}

void parent_work(char* file, int n) 
{
    sethandler(sigint_handler, SIGINT);

    int fd = TEMP_FAILURE_RETRY(open(file, O_RDONLY));
    if (fd < 0) 
    {
        ERR("open");
    }

    struct stat file_stat;
    if (fstat(fd, &file_stat) < 0) 
    {
        ERR("fstat");
    }
    size_t file_size = file_stat.st_size;

    char *buf = malloc(file_size);
    if (!buf) 
    {
        ERR("malloc");
    }

    int length = bulk_read(fd, buf, file_size);
    if (length != file_size) 
    {
        ERR("bulk_read");
    }

    if (TEMP_FAILURE_RETRY(close(fd)) < 0) 
    {
        ERR("close");
    }

    int child_fragment_size = length / n;
    pid_t children[n];

    for (int i = 0; i < n; i++) 
    {
        pid_t pid = fork();

        if (pid < 0) 
        {
            ERR("fork");
        }

        if (pid == 0) 
        {
            int start = i * child_fragment_size;
            int size = (i == n - 1) ? length - start : child_fragment_size;
            child_work(buf + start, size, file, i + 1);
        }

        children[i] = pid;
    }

    sleep(1); // Give children time to pause()

    for (int i = 0; i < n; i++)
    {
        if (kill(children[i], SIGUSR1) < 0)
        {
            ERR("kill");
        }
    }

    while (wait(NULL) > 0)
    {
        ;
    }

    // Handle SIGINT
    if (sigint_received) 
    {
        printf("Parent received SIGINT, sending SIGINT to children.\n");
        for (int i = 0; i < n; i++) 
        {
            if (kill(children[i], SIGINT) < 0) 
            {
                ERR("kill");
            }
        }

        for (int i = 0; i < n; i++) 
        {
            while (1) 
            {
                pid_t pid = wait(NULL);
                if (pid < 0) 
                {
                    if (errno == EINTR) 
                    {
                        continue;  // Retry on interruption
                    }
                    break;  // Exit on other errors
                }
            }
        }

        exit(EXIT_SUCCESS);  // Parent exits after children
    }

    free(buf);

    printf("All processes terminated.\n");
}

void usage(int argc, char* argv[]) 
{
    printf("%s p k \n", argv[0]);
    printf("\tp - path to file to be encrypted\n");
    printf("\tk - number of child processes (0 < k < 8)\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char* argv[]) 
{
    char *file;
    int n;

    if (argc != 3) 
    {
        usage(argc, argv);
    }

    file = argv[1];
    n = atoi(argv[2]);

    if (n <= 0 || n >= 8) 
    {
        usage(argc, argv);
    }

    sethandler(sigint_handler, SIGINT);  // Set SIGINT handler for parent process

    parent_work(file, n);

    return EXIT_SUCCESS;
}
