#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

#define MAXLINE 4096
#define DEFAULT_ARRAYSIZE 10
#define DELETED_ITEM -1
#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

typedef struct argsSiganlHandler
{
    pthread_t tid;
    int *pArrayCount;
    int *array;
    pthread_mutex_t *pmxArray;
    sigset_t *pMask;
    bool *pQuitFlag;
    pthread_mutex_t *pmxQuitFlag;

}argsSiganlHandler_t;

void ReadArguments(int argc, char **argv, int *arraySize);
void removeItem(int *array, int *arrayCount, int index);
void printArray(int *array, int arraySize);
void *signal_handling(void *);

int main(int argc, char **argv)
{
    int arraySize, *array;
    bool quitFlag = false; //flag to indicate when to stop
    
    pthread_mutex_t mxQuitFlag = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t mxArray = PTHREAD_MUTEX_INITIALIZER;

    ReadArguments(argc, argv, &arraySize); //reading the input

    int arrayCount = arraySize; //track the active elements the array

    if(NULL == (array = (int *)malloc(sizeof(int) * arraySize)))
    {
        ERR("malloc");
    }

    //numbers from 1 to arraySize
    for(int i = 0; i < arraySize; i++)
    {
        array[i] = i + 1;
    }

    //The program uses signal masks and blocks signals in the main thread to ensure that signals (SIGINT and SIGQUIT) are handled only by the dedicated signal-handling thread
    sigset_t oldMask, newMask;

    sigemptyset(&newMask);
    sigaddset(&newMask, SIGINT);
    sigaddset(&newMask, SIGQUIT);

    if(pthread_sigmask(SIG_BLOCK, &newMask, &oldMask))
    {
        ERR("pthread_sigmask");
    }

    argsSiganlHandler_t args;

    args.pArrayCount = &arrayCount;
    args.array = array;
    args.pmxArray = &mxArray;
    args.pMask = &newMask;
    args.pQuitFlag = &quitFlag;
    args.pmxQuitFlag = &mxQuitFlag;

    //creating main thread
    if (pthread_create(&args.tid, NULL, signal_handling, &args))
    {
        ERR("pthread_create");
    }

    while(true)
    {
        pthread_mutex_lock(&mxQuitFlag);

        if (quitFlag == true) //if quitFlag is set we end 
        {
            pthread_mutex_unlock(&mxQuitFlag);
            break;
        }
        else //otherwsie we lock mxArray to print the current array
        {
            pthread_mutex_unlock(&mxQuitFlag);
            pthread_mutex_lock(&mxArray);
            printArray(array, arraySize);
            pthread_mutex_unlock(&mxArray);
            sleep(1);
        }
    }

    //waits for signal handling thread to terminate
    if (pthread_join(args.tid, NULL))
    {
        ERR("Can't join with 'signal handling' thread");
    }

    free(array);

    if (pthread_sigmask(SIG_UNBLOCK, &newMask, &oldMask))
    {
        ERR("SIG_BLOCK error");
    }
    
    exit(EXIT_SUCCESS);

}

void ReadArguments(int argc, char **argv, int *arraySize)
{
    *arraySize = DEFAULT_ARRAYSIZE;

    //The program takes sole ‘k’ parameter and prints the list of numbers form 1 to k
    if(argc >= 2)
    {
        *arraySize = atoi(argv[1]);

        if(*arraySize <= 0)
        {
            printf("Invalid value for array size");
            exit(EXIT_FAILURE);
        }
    }
}

//removes random number from the list (do nothing if empty),
void removeItem(int *array, int *arrayCount, int index)
{
    int currentIndex = -1;
    int i = -1;

    //search for randomly generated index
    while(currentIndex != index)
    {
        i++;

        if(array[i] != DELETED_ITEM) 
        {
            currentIndex++;
        }
    }

    array[i] = DELETED_ITEM; //when we found edsired index we assign deleted item to it
    *arrayCount -= 1; //we decrease the number of elements in the array
}

void printArray(int *array, int arraySize)
{
    //The program takes sole ‘k’ parameter and prints the list of numbers form 1 to k
    printf("[");

    for(int i = 0; i < arraySize; i++)
    {
        if(array[i] != DELETED_ITEM)
        {
            printf(" %d", array[i]);
        }
    }

    printf(" ]\n");
}

void *signal_handling(void *voidArgs)
{
    argsSiganlHandler_t *args = voidArgs;
    int signo;

    srand(time(NULL));

    for(;;)
    {
        if(sigwait(args->pMask, &signo)) //waiting for the signal
        {
            ERR("sigwait");
        }

        switch(signo)
        {
            case SIGINT:
                pthread_mutex_lock(args->pmxArray); //lock mutex to not delete 2 numbers at the same time
                if(*args->pArrayCount > 0)
                {
                    //removing random number
                    removeItem(args->array, args->pArrayCount, rand() % (*args->pArrayCount));
                }
                pthread_mutex_unlock(args->pmxArray);
                break;
            case SIGQUIT:
                //set program ‘STOP’ flag (both threads end)
                pthread_mutex_lock(args->pmxQuitFlag);
                *args->pQuitFlag = true;
                pthread_mutex_unlock(args->pmxQuitFlag);
                return NULL;
            default:
                printf("Unexpected signal, which we don't have idea how to handle");
                exit(1);
        }
    }

    return NULL;
}



