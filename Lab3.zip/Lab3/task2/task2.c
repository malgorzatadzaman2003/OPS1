#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <math.h>

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

#define MIN_N 8
#define MAX_N 256
#define MIN_P 1
#define MAX_P 16

typedef unsigned int UINT;
typedef struct timespec timespec_t;

typedef struct threadArgs
{
    int *array;
    UINT seed;
    pthread_mutex_t *mutexes;
    int n; //array size
    int p;
    int active_threads;
    pthread_mutex_t thread_counter_mutex;
}threadArgs_t;

void msleep(UINT milisec)
{
    time_t sec = (int)(milisec / 1000);
    milisec = milisec - (sec * 1000);

    timespec_t req = {0};
    req.tv_sec = sec;
    req.tv_nsec = milisec * 1000000L;

    if (nanosleep(&req, &req))
    {
        ERR("nanosleep");
    }
}

void ReadArguments(int argc, char **argv, int *threadCount, int *sampleCount);
void init_array_and_mutexes(void *voidArgs, int n, int p);
void cleanup(void *voidArgs);
void *handle_sigusr1(void *voidArgs);
void swap_elements(void *voidArgs, int a, int b);

void usage(int argc, char* argv[])
{
    printf("%s n p\n", argv[0]);
    printf("\t8 <= n <= 256 - integre in rand [8;256]\n");
    printf("\t1 <= p <= 16 - number of working threads running at the same time.\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    int n, threadCount;

    ReadArguments(argc, argv, &n, &threadCount);

    srand(time(NULL)); // Only call srand once

    threadArgs_t args;

    init_array_and_mutexes(&args, n, threadCount);

    // Block SIGUSR1 in the main thread and all threads by default
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGUSR1);
    if (pthread_sigmask(SIG_BLOCK, &set, NULL) != 0) 
    {
        cleanup(&args);
        ERR("pthread_sigmask");
    }

    // Create the signal-handling thread
    pthread_t sig_thread;
    if (pthread_create(&sig_thread, NULL, handle_sigusr1, &args) != 0) 
    {
        cleanup(&args);
        ERR("pthread_create");
    }

    printf("Array initialized. Waiting for SIGUSR1...\n");

    // Join the signal-handling thread (it runs indefinitely)
    if (pthread_join(sig_thread, NULL) != 0)
    {
        cleanup(&args);
        ERR("pthread_join");
    }

    cleanup(&args);
    return 0;
}

void ReadArguments(int argc, char **argv, int *n, int *threadCount)
{
    *n = MIN_N;
    *threadCount = MIN_P;

    if(argc >= 2)
    {
        *n = atoi(argv[1]);

        if(*n < MIN_N || *n > MAX_N)
        {
            printf("Invalid value for 'n'\n");
            exit(EXIT_FAILURE);
        }
    }

    if(argc >= 3)
    {
        *threadCount = atoi(argv[2]);
        
        if(*threadCount < MIN_P || *threadCount > MAX_P)
        {
            printf("Invalid value for 'threadCount'\n");
            exit(EXIT_FAILURE);
        }
    }
}

void init_array_and_mutexes(void *voidArgs, int n, int p)
{
    threadArgs_t *args = (threadArgs_t *)voidArgs;

    args->n = n;
    args->p = p;
    args->active_threads = 0;

    args->array = malloc(n * sizeof(int));
    args->mutexes = malloc(n * sizeof(pthread_mutex_t));
    if(!args->array || !args->mutexes)
    {
        ERR("malloc");
    }

    args->seed = rand();

    for(int i = 0; i < n; i++)
    {
        args->array[i] = i;

        if(pthread_mutex_init(&args->mutexes[i], NULL) != 0)
        {
            cleanup(args);
            ERR("pthread_mutex_init");
        }
    }

    if (pthread_mutex_init(&args->thread_counter_mutex, NULL) != 0) 
    {
        cleanup(args);
        ERR("pthread_mutex_init");
    }
}

void cleanup(void *voidArgs)
{
    threadArgs_t *args = (threadArgs_t *)voidArgs;

    for(int i = 0; i < args->n; i++)
    {
        pthread_mutex_destroy(&args->mutexes[i]);
    }

    free(args->mutexes);
    pthread_mutex_destroy(&args->thread_counter_mutex);
}

void *handle_sigusr1(void *voidArgs)
{
    threadArgs_t *args = (threadArgs_t *)voidArgs;
    sigset_t newMask;
    int sig;

    // Block SIGUSR1 in this thread
    sigemptyset(&newMask);
    sigaddset(&newMask, SIGUSR1);
    if (pthread_sigmask(SIG_BLOCK, &newMask, NULL) != 0) 
    {
        ERR("pthread_sigmask");
    }

    while (1) {
        // Wait for SIGUSR1
        if (sigwait(&newMask, &sig) != 0) 
        {
            ERR("sigwait");
        }

        if (sig == SIGUSR1) 
        {
            int a, b;
            int retries = 0;
            do 
            {
                a = rand_r(&args->seed) % args->n;
                b = rand_r(&args->seed) % args->n;
                retries++;

                if (a < b) {
                    break;
                }

                if (retries > 100) 
                {
                    ERR("Unable to generate valid a < b after 100 retries");
                }
            } while (a >= b);

            printf("SIGUSR1 received: Swapping elements between a: %d and b: %d\n", a, b);
            swap_elements(args, a, b);
            msleep(5);
        }
    }

    return NULL;
}

void swap_elements(void *voidArgs, int a, int b)
{
    threadArgs_t *args = (threadArgs_t *)voidArgs;

    if (a < 0 || b < 0 || a >= args->n || b >= args->n) 
    {
        ERR("Invalid indices for swapping");
    }

    // Ensure a is always less than b
    if (a > b) 
    {
        int temp = a;
        a = b;
        b = temp;
    }
    
    for(int i = 0; a + i < b - i; i++)
    {
        int idx1 = a + i;
        int idx2 = b - i;

        pthread_mutex_lock(&args->mutexes[idx1]);
        pthread_mutex_lock(&args->mutexes[idx2]);

        int temp = args->array[idx1];

        //swaping
        args->array[idx1] = args->array[idx2];
        args->array[idx2] = temp;

        pthread_mutex_unlock(&args->mutexes[idx1]);
        pthread_mutex_unlock(&args->mutexes[idx2]);

        printf("Now a: %d and b: %d\n", args->array[idx1], args->array[idx2]);
    }
}