#include <math.h>
#include <pthread.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 4096
#define DEFAULT_THREADCOUNT 10
#define DEFAULT_SAMPLESIZE 100

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

typedef unsigned int UINT;

//structure to pass arguments to each thread
typedef struct argsEstimation
{
    pthread_t tid;
    UINT seed;
    int sampleCount;
}argsEstimation_t;

void ReadArguments(int argc, char **argv, int *threadCount, int *sampleCount);
void *pi_estimation(void *args);

int main(int argc, char **argv)
{
    int threadCount, sampleCount;
    double *piSubResult;

    ReadArguments(argc, argv, &threadCount, &sampleCount);

    //allocate memory for pi estimations
    argsEstimation_t *pi_estimations = (argsEstimation_t *)malloc(sizeof(argsEstimation_t) * threadCount);

    if(pi_estimations == NULL)
    {
        ERR("malloc");
    }

    srand(time(NULL));

    //initialize properties for each thread
    for(int i = 0; i < threadCount; i++)
    {
        pi_estimations[i].seed = rand();
        pi_estimations[i].sampleCount = sampleCount;
    }

    //creating each thread
    for(int i = 0; i < threadCount; i++)
    {
        int err = pthread_create(&(pi_estimations[i].tid), NULL, pi_estimation, &pi_estimations[i]);

        if(err != 0)
        {
            ERR("pthread_create");
        }
    }

    double piCumulativeResult = 0.0;

    //wait for all threads to finish and calculate cumulative resuts
    for(int i = 0; i < threadCount; i++)
    {
        //Wait for all threads to finish
        int err = pthread_join(pi_estimations[i].tid, (void *)&piSubResult);

        if(err != 0)
        {
            ERR("pthread_join");
        }

        if(NULL != piSubResult)
        {
            piCumulativeResult += *piSubResult;
            free(piSubResult);
        }
    }

    //approximate valu of pi
    double piFinalResult = piCumulativeResult / threadCount;
    printf("PI ~= %f\n", piFinalResult);
    free(pi_estimations);
}

void ReadArguments(int argc, char **argv, int *threadCount, int *sampleCount)
{
    *threadCount = DEFAULT_THREADCOUNT;
    *sampleCount = DEFAULT_SAMPLESIZE;

    if(argc >= 2)
    {
        *threadCount = atoi(argv[1]);

        if(*threadCount <= 00)
        {
            printf("Invalid value for 'threadCount'");
            exit(EXIT_FAILURE);
        }
    }

    if(argc >= 3)
    {
        *sampleCount = atoi(argv[2]);
        
        if(*sampleCount <= 00)
        {
            printf("Invalid value for 'sampleCount'");
            exit(EXIT_FAILURE);
        }
    }
}

//Monte-Carlo method to approximate π
void *pi_estimation(void *voidPtr)
{
    argsEstimation_t *args = voidPtr;
    double *pi_result;

    if(NULL == (pi_result = malloc(sizeof(double))))
    {
        ERR("malloc");
    }

    int insideDotsCount = 0;

    for(int i = 0; i < args->sampleCount; i++)
    {
        //Another Monte Carlo method for computing π is to draw a circle inscribed in a square. 
        double x = ((double)rand_r(&args->seed) / (double)RAND_MAX);
        double y = ((double)rand_r(&args->seed) / (double)RAND_MAX);

        //and randomly place dots in the square
        if(sqrt(x * x + y * y) <= 1)
        {
            insideDotsCount++;
        }
    }

    //The ratio of dots inside the circle to the total number of dots will approximately equal π/4
    *pi_result = 4.0 * (double)insideDotsCount / (double)args->sampleCount;
    return pi_result;
}