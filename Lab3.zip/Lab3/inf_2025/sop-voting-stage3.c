#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

#define CANDIDATES 256
#define MAX_STATES 100


typedef unsigned int UINT;
typedef struct timespec timespec_t;

void msleep(UINT milisec)
{
    time_t sec = (int)(milisec / 1000);
    milisec = milisec - (sec * 1000);

    timespec_t req = {0};
    req.tv_sec = sec;
    req.tv_nsec = milisec * 1000000L;

    if (nanosleep(&req, &req))
    {
        ERR("nanosleep");
    }
}

ssize_t bulk_read(int fd, char* buf, size_t count)
{
    ssize_t c;
    ssize_t len = 0;
    do
    {
        c = TEMP_FAILURE_RETRY(read(fd, buf, count));
        if (c < 0)
            return c;
        if (c == 0)
            return len;  // EOF
        buf += c;
        len += c;
        count -= c;
    } while (count > 0);
    return len;
}

/**
 * @struct queue
 * @brief Data structure to represent a thread-safe queue.
 */
typedef struct queue
{
    char** paths;         /**< Array to store paths in the queue. */
    int head;             /**< Index of the head of the queue. */
    int tail;             /**< Index of the tail of the queue. */
    int count;            /**< Current number of elements in the queue. */
    int size;             /**< Maximum size of the queue. */
    int completed_adding; /**< Flag to indicate all paths have been added to the queue. */
    pthread_mutex_t mutex; /**< Mutex to ensure thread-safe access to the queue. */
}queue_t;

typedef struct threadArgs
{
    queue_t* queue;
    pthread_t tid;
    pthread_mutex_t* mutexes; // "Each field of this array is protected by a separate mutex"
    int* votes; //"Threads count votes into a shared array"

    // Signal handling
    sigset_t* pMask;
    int* finished;
    pthread_mutex_t* finished_mutex;
}threadArgs_t;

/**
 * @brief Initializes a queue.
 *
 * Allocates memory for a new queue instance and initializes its members.
 *
 * @param size The maximum number of paths the queue can hold.
 * @return Pointer to the initialized queue.
 */
queue_t* queue_init(int size) 
{ 
    queue_t* q;

    //Allocates memory for a new queue instance
    if(NULL == (q = (queue_t *)malloc(sizeof(queue_t)))) 
    {
        ERR("malloc");
    } 

    char** p;

    if(NULL == (p = calloc(size, sizeof(char*))))
    {
        ERR("calloc");
    }

    //initializes its members
    q->size = size;
    q->count = 0;
    q->completed_adding = 0;
    q->head = 0;
    q->tail = 0;
    q->paths = p;

    pthread_mutex_init(&q->mutex, NULL);

    return q;
}

/**
 * @brief Adds a path to the queue.
 *
 * Waits 50ms if the queue is full until space becomes available (busy-wait loop).
 * Returns 0 if queue_complete_adding was called, 1 if the item was successfully added.
 *
 * @note This function duplicates the input string using `strdup`. The caller
 *       is responsible for freeing the memory of the input string if necessary,
 *       but the queue manages its own storage for paths.
 *
 * @param queue Pointer to the queue.
 * @param path Task to add to the queue (a string).
 * @return Flag if the operation was successful.
 */
int queue_enqueue(queue_t* queue, char* path) 
{ 
    if(pthread_mutex_lock(&queue->mutex))
    {
        ERR("pthread_mutex_lock");
    }

    //if the queue is full we wait 50ms
    while(queue->count == queue->size && queue->completed_adding == 0)
    {
        if(pthread_mutex_unlock(&queue->mutex))
        {
            ERR("pthread_mutex_unlock");
        }

        msleep(50);

        if(pthread_mutex_lock(&queue->mutex))
        {
            ERR("pthread_mutex_lock");
        }
    }

    //if the adding was completed we return
    if(queue->completed_adding == 1)
    {
        if(pthread_mutex_unlock(&queue->mutex))
        {
            ERR("pthread_mutex_unlock");
        }

        return 0; //Returns 0 if queue_complete_adding was called
    }

    //allocating paths and adding each path to the queue
    queue->paths[queue->tail] = strdup(path);
    queue->tail++;

    if(queue->tail >= queue->size)
    {
        queue->tail = 0;
    }
    queue->count++;

    if(pthread_mutex_unlock(&queue->mutex))
    {
        ERR("pthread_mutex_unlock");
    }

    return 1; //returns 1 if the item was successfully added
}

/**
 * @brief Marks the queue as no longer accepting new paths.
 *
 * This indicates that no more paths will be added to the queue.
 *
 * @param queue Pointer to the queue.
 */
void queue_complete_adding(queue_t* queue) 
{
    if(pthread_mutex_lock(&queue->mutex))
    {
        ERR("pthread_mutex_lock");
    }

    queue->completed_adding = 1;
    
    if(pthread_mutex_unlock(&queue->mutex))
    {
        ERR("pthread_mutex_unlock");
    }
}

/**
 * @brief Removes a path from the queue.
 *
 * Waits 5ms if the queue is empty until a new path is available. (busy-wait loop).
 * Returns NULL if no paths are available and queue_complete_adding was called.
 *
 * @param queue Pointer to the queue.
 * @return Pointer to the path string. NULL if no paths are available and adding is completed.
 */
char* queue_dequeue(queue_t* queue) 
{ 
    if(pthread_mutex_lock(&queue->mutex))
    {
        ERR("pthread_mutex_lock");
    }

    //Waits 5ms if the queue is empty until a new path is available.
    while(queue->count == 0 && queue->completed_adding == 0)
    {
        if(pthread_mutex_unlock(&queue->mutex))
        {
            ERR("pthread_mutex_unlock");
        }

        msleep(5);

        if(pthread_mutex_lock(&queue->mutex))
        {
            ERR("pthread_mutex_lock");
        }        
    }

    if(queue->completed_adding == 1 && queue->count == 0)
    {
        if(pthread_mutex_unlock(&queue->mutex))
        {
            ERR("pthread_mutex_unlock");
        }

        return NULL; //Returns NULL if no paths are available and queue_complete_adding was called.
    }

    //removing element from the queue
    char* p = queue->paths[queue->head];
    // Asign NULL after removing to ensure no problems with free() later
    queue->paths[queue->head] = NULL;
    queue->head = (queue->head + 1) % queue->size;
    queue->count--;

    if(pthread_mutex_unlock(&queue->mutex))
    {
        ERR("pthread_mutex_unlock");
    }

    return p;
}

/**
 * @brief Cleans up the queue and releases all resources.
 *
 * Frees memory allocated for the paths and the queue structure.
 * Destroys the mutex associated with the queue.
 *
 * @param queue Pointer to the queue to be disposed.
 */
void queue_dispose(queue_t* queue) 
{
    // We may assume only one thread will call this function (same with init)

    //Frees memory allocated for the paths
    for(int i = 0; i < queue->size; i++)
    {
        //freeing NULL is safe
        free(queue->paths[i]);
    }

    free(queue->paths);

    //Destroys the mutex associated with the queue.
    if(pthread_mutex_destroy(&queue->mutex))
    {
        ERR("pthread_mutex_destroy");
    }

    //Frees memory allocated the queue structure
    free(queue);
}

void scan_dir(char* p, queue_t* q)
{
    DIR* dirp;
    struct dirent* dp;
    struct stat filestat;

    if((dirp = opendir(p)) == NULL)
    {
        ERR("opendir");
    }

    do
    {
        errno = 0;

        if((dp = readdir(dirp)) != NULL)
        {
            //The main thread scans directory p for files and places their paths into a queue with a capacity of 1 <= q <= 8
            char path[PATH_MAX];
            snprintf(path, sizeof(path), "%s/%s", p, dp->d_name);

            if(lstat(path, &filestat))
            {
                ERR("lstat");
            }

            if(S_ISREG(filestat.st_mode))
            {
                if(!queue_enqueue(q, path))
                {
                    break;
                }
            }
        }
    } while (dp != NULL);
    
    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }
}

void* start_routine(void* voidArgs)
{
    threadArgs_t* args = (threadArgs_t*)voidArgs;
    char* path;

    while((path = queue_dequeue(args->queue)))
    {
        //Worker threads retrieve paths from the queue and print them along with their id until no new paths are available, after which the threads terminate.
        // Print the thread ID and the file path
        printf("Thread[%lu] processing file: %s\n", (unsigned long)pthread_self(), path);
        
        int fd;

        //open file for reading
        if((fd = open(path, O_RDONLY)) == -1)
        {
            ERR("open");
        }

        //Votes are read in batches into a buffer of size 256 bytes, and then counted one by one from the buffer
        char buff[256];
        int read;

        while(1)
        {
            // Check if counting is finished (using mutex to protect shared state)
            if(pthread_mutex_lock(args->finished_mutex))
            {
                ERR("pthread_mutex_lock");
            }

            //if we finish counting earlier, break
            if(*(args->finished))
            {
                if(pthread_mutex_unlock(args->finished_mutex))
                {
                    ERR("pthread_mutex_unlock");
                }

                break;
            }

            if(pthread_mutex_unlock(args->finished_mutex))
            {
                ERR("pthread_mutex_unlock");
            }

            if((read = bulk_read(fd, buff, sizeof(buff))) == -1)
            {
                ERR("bulk_read");
            }

            if(read == 0) //end of file
            {
                break;
            }

            //// Count votes (1 byte = 1 vote)
            for(int i = 0; i < read; i++)
            {
                int candidate = (unsigned char)buff[i];  // Get candidate index

                // Lock the mutex for the current candidate
                if(pthread_mutex_lock(&args->mutexes[i]))
                {
                    ERR("pthread_mutex_lock");
                }

                args->votes[candidate]++; //counting ecah vote

                msleep(1); //after counting each vote, threads sleep for 1 ms.

                if(pthread_mutex_unlock(&args->mutexes[i]))
                {
                    ERR("pthread_mutex_unlock");
                }
            }
        }

        if(close(fd))
        {
            ERR("close");
        }

        free(path);

        if(pthread_mutex_lock(args->finished_mutex))
        {
            ERR("pthread_mutex_lock");
        }

        // If we finished counting earlier, break
        if (*(args->finished))
        {
            if (pthread_mutex_unlock(args->finished_mutex))
            {
                ERR("mutex unlock");
            }

            break;
        }

        if (pthread_mutex_unlock(args->finished_mutex))
        {
            ERR("mutex unlock");
        }
    }

    return NULL; // Terminate the thread
}

void print_votes(int votes[CANDIDATES])
{

    for (int i = 0; i < CANDIDATES; i++)
    {
        printf("Candidate no %d: %3d \n", i+1, votes[i]);
    }
    printf("\n");
}

void usage(int argc, char* argv[])
{
    printf("%s p q t\n", argv[0]);
    printf("\tp - path to file to be encrypted\n");
    printf("\t1 <= q <= 8 - size of paths queue\n");
    printf("\t1 <= t <= 16 - number of processing threads\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char* argv[])
{
    if (argc != 4) 
    {
        usage(argc, argv);
    }

    char* dir_path = argv[1];
    int queue_size = atoi(argv[2]);
    int thread_count = atoi(argv[3]);
    
    if (queue_size < 1 || queue_size > 8)
    {
        usage(argc, argv);
    }

    if (thread_count < 1 || thread_count > 16)
    {
        usage(argc, argv);
    }

    queue_t* queue = queue_init(queue_size);
    threadArgs_t* args = calloc(thread_count, sizeof(threadArgs_t));  
    
    if (!args) 
    {
        ERR("calloc");
    }

    // Array for counting votes
    int votes[256] = {0};
    pthread_mutex_t mutexes[256];

    // Initialize the mutexes before starting any threads
    for (int i = 0; i < 256; i++) 
    {
        if (pthread_mutex_init(&mutexes[i], NULL)) 
        {
            ERR("pthread_mutex_init");
        }   
    }

    // For signal handling
    pthread_mutex_t finished_mut = PTHREAD_MUTEX_INITIALIZER;
    int finished = 0;

    //creating worker threads
    for (int i = 0; i < thread_count; i++)
    {
        // Initializing threadArgs struct
        args[i].queue = queue;
        args[i].mutexes = mutexes;
        args[i].votes = votes;
        args[i].finished_mutex = &finished_mut;
        args[i].finished = &finished;

        if(pthread_create(&args[i].tid, NULL, start_routine, &args[i]))
        {
            ERR("pthread_create");
        }
    }

    scan_dir(dir_path, queue);
    queue_complete_adding(queue);

    for (int i = 0; i < thread_count; i++) 
    {
        pthread_join(args[i].tid, NULL);
    }

    for (int i = 0; i < 256; i++)
    {
        if (pthread_mutex_destroy(&mutexes[i]))
        {
            ERR("mutex destroy");
        }
    }

    print_votes(votes);

    free(args);

    queue_dispose(queue);

    return EXIT_SUCCESS;
}
