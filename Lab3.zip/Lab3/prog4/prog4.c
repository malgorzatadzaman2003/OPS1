#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXLINE 4096
#define DEFAULT_STUDENT_COUNT 100 //default number of students if no argument is provided 
#define ELAPSED(start, end) ((end).tv_sec - (start).tv_sec) + (((end).tv_nsec - (start).tv_nsec) * 1.0e-9)
#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

typedef unsigned int UINT;

typedef struct timespec timespec_t;

typedef struct studentsList
{
    bool *removed;
    pthread_t *thStudents;
    int count;
    int present;
}studentsList_t;

typedef struct yearCounters
{
    int values[4];
    pthread_mutex_t mxCounters[4];
}yearCounters_t;

typedef struct argsModify
{
    yearCounters_t *pYearCounters;
    int year;
}argsModify_t;

void ReadArguments(int argc, char **argv, int *studentsCount);
void *student_life(void *);
void increment_counter(argsModify_t *args);
void decrement_counter(void *args);
void msleep(UINT milisec);
void kick_student(studentsList_t *studentList);

int main(int argc, char **argv)
{
    int studentsCount;

    ReadArguments(argc, argv, &studentsCount);

    yearCounters_t counters = {.values = {0, 0, 0, 0},
                               .mxCounters = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER}};

    //main thread- initiate students
    studentsList_t studentsList;
    studentsList.count = studentsCount;
    studentsList.present = studentsCount;
    studentsList.thStudents = (pthread_t *)malloc(sizeof(pthread_t) * studentsCount);
    studentsList.removed = (bool *)malloc(sizeof(bool) * studentsCount);

    if(studentsList.thStudents == NULL || studentsList.removed == NULL)
    {
        ERR("malloc");
    }

    // Initialize the array to false
    for (int i = 0; i < studentsCount; i++)
    {
        studentsList.removed[i] = false;
    }

    //create student threads 
    for(int i = 0; i < studentsCount; i++)
    {
        if(pthread_create(&studentsList.thStudents[i], NULL, student_life, &counters))
        {
            ERR("pthread_create");
        }
    }

    srand(time(NULL));

    timespec_t start, current;

    if(clock_gettime(CLOCK_REALTIME, &start)) //getting the start time
    {
        ERR("clock_gettime");
    }

    //main thread- for 4 seconds at random intervals (100-300ms) strike off one of the students (cancel thread)
    do
    {
        msleep(rand() % 201 + 100); 

        if(clock_gettime(CLOCK_REALTIME, &current))
        {
            ERR("clock_gettime");
        }

        kick_student(&studentsList);
    } while (ELAPSED(start, current) < 4.0); 

    //After the 4s period waits for the students threads to end 
    for(int i = 0; i < studentsCount; i++)
    {
        if(pthread_join(studentsList.thStudents[i], NULL))
        {
            ERR("pthread_join");
        }
    }
    
    //and prints the counters.
    printf(" First year students: %d\n", counters.values[0]);
    printf("Second year students: %d\n", counters.values[1]);
    printf("Third year students: %d\n", counters.values[2]);
    printf("Engineers: %d\n", counters.values[3]);

    free(studentsList.removed);
    free(studentsList.thStudents);

    exit(EXIT_SUCCESS);
}

void ReadArguments(int argc, char **argv, int *studentsCount)
{
    *studentsCount = DEFAULT_STUDENT_COUNT;

    //The program takes the following parameter: n <= 100 … count of new students
    if(argc >= 2)
    {
        *studentsCount = atoi(argv[1]);

        if(*studentsCount <= 0 || *studentsCount > 100)
        {
            printf("Invalid value for number of students");
            exit(EXIT_FAILURE);
        }
    }
}

void *student_life(void *voidArgs)
{
    //Sets the thread's cancellation type to deferred, meaning cancellation will occur only at specific points (e.g., pthread_cleanup_pop or blocking functions).
    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);

    argsModify_t args;

    args.pYearCounters = voidArgs;

    for(args.year = 0; args.year < 3; args.year++) //loops through first three years: 1,2,3 not engineers
    {
        increment_counter(&args); //increments counter for current year - (Student (thread) adds itself to the counter of the first year)
        pthread_cleanup_push(decrement_counter, &args); //registers a cleanup handler (decrement_counter) for the current year. If the thread is canceled, this function will run to decrement the counter for the current year.
        msleep(1000); //after a second it removes itself from it and adds to the second year counter and so on until it reaches the BSc counter
        pthread_cleanup_pop(1);
    }

    increment_counter(&args); //After the loop, increments the counter for the final (4th) year and exits the thread.
    return NULL;
}

void increment_counter(argsModify_t *args)
{
    pthread_mutex_lock(&(args->pYearCounters->mxCounters[args->year])); //Locks the mutex for the specific year to safely modify the shared counter.
    args->pYearCounters->values[args->year] += 1; //Increments the counter for the current year.
    pthread_mutex_unlock(&(args->pYearCounters->mxCounters[args->year]));
}

void decrement_counter(void *_args)
{
    argsModify_t *args = _args;

    pthread_mutex_lock(&(args->pYearCounters->mxCounters[args->year]));
    args->pYearCounters->values[args->year] -= 1;
    pthread_mutex_unlock(&(args->pYearCounters->mxCounters[args->year]));
}

void msleep(UINT milisec)
{
    //Converts the input milliseconds into seconds and the remaining milliseconds.
    time_t sec = (int)(milisec / 1000);
    milisec = milisec - (sec * 1000);

    timespec_t req = {0};
    req.tv_sec = sec;
    req.tv_nsec = milisec * 1000000L;

    if(nanosleep(&req, &req))
    {
        ERR("nanosleep");
    }
}

void kick_student(studentsList_t *studentsList)
{
    int index;

    if(0 == studentsList->present) //checking if there are any students left to kick
    {
        return;
    }

    do
    {
        index = rand() % studentsList->count; //randomly choose student index that hasn't been removed yet
    } while (studentsList->removed[index] == true);
    
    pthread_cancel(studentsList->thStudents[index]);
    
    //Marks the student as removed and decrements the count of present students.
    studentsList->removed[index] = true;
    studentsList->present--;
}