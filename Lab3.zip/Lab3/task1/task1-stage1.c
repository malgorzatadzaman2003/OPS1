#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

#define MAXLINE 4096
#define DEFAULT_THREADS_COUNT 100
#define DEFAULT_ARRAYSIZE 10
#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

void ReadArguments(int argc, char **argv, int *threads_count, int *arraySize);
void* print_star(void *voidArgs);

int main(int argc, char **argv)
{
    int arraySize, threads_count;
    pthread_t threads[DEFAULT_THREADS_COUNT];

    ReadArguments(argc, argv, &threads_count, &arraySize); //reading the input

    //create threads_count processing threads 
    for(int i = 0; i < threads_count; i++)
    {
        if(pthread_create(&threads[i], NULL, print_star, NULL))
        {
            ERR("pthread_create");
        }
    }

    //Main thread is waiting for all threads.
    for(int i = 0; i < threads_count; i++)
    {
        if(pthread_join(threads[i], NULL))
        {
            ERR("pthread_join");
        }
    }

    exit(EXIT_SUCCESS);
}

void ReadArguments(int argc, char **argv, int *threads_count, int *arraySize)
{
    *arraySize = DEFAULT_ARRAYSIZE;
    *threads_count = DEFAULT_THREADS_COUNT;

    //The program takes 2 input parameters: n,k. where n is the number of processing posix threads and k is the task array size
    if(argc >= 3)
    {
        *threads_count = atoi(argv[1]);
        *arraySize = atoi(argv[2]);

        if(*arraySize <= 0 || *threads_count <= 0)
        {
            printf("Invalid value for array size or threads count");
            exit(EXIT_FAILURE);
        }
    }
}

void* print_star(void *voidArgs)
{
    printf("*\n");
    return NULL;
}



