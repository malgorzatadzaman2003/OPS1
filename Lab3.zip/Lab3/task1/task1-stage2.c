#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

#define MAXLINE 4096
#define DEFAULT_THREADS_COUNT 100
#define DEFAULT_ARRAYSIZE 10
#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

void ReadArguments(int argc, char **argv, int *threads_count, int *arraySize);
void* print_star(void *voidArgs);
void* thread_process_task(void *args);
void print_array(float *array, int size);

typedef struct threadArgs
{
    int threads_count;
    int arraySize;
    float *task;
}threadArgs_t;

int main(int argc, char **argv)
{
    int arraySize, threads_count;
    float *task_array;
    pthread_t *threads;
    threadArgs_t *args;

    ReadArguments(argc, argv, &threads_count, &arraySize); //reading the input

    //allocate memory for the task array
    task_array = (float *)malloc(arraySize * sizeof(float));
    if (!task_array) 
    {
        ERR("malloc");
    }

    // Main thread is filling the task array and prints it
    for (int i = 0; i < arraySize; i++) 
    {
        task_array[i] = (rand() % 60) + 1.0;
    }

    // Print the task array
    printf("Task Array: ");
    print_array(task_array, arraySize);
    printf("\n");

    // Allocate memory for the threads
    threads = (pthread_t *)malloc(threads_count * sizeof(pthread_t));
    args = (threadArgs_t *)malloc(threads_count * sizeof(threadArgs_t));
    if (!threads || !args) 
    {
        ERR("malloc");
    }

    //create threads_count processing threads 
    for(int i = 0; i < threads_count; i++)
    {
        args[i].threads_count = threads_count;
        args[i].arraySize = arraySize;
        args[i].task = task_array;

        if(pthread_create(&threads[i], NULL, thread_process_task, (void *)&args[i]))
        {
            ERR("pthread_create");
        }
    }

    //Main thread is waiting for all threads.
    for(int i = 0; i < threads_count; i++)
    {
        if(pthread_join(threads[i], NULL))
        {
            ERR("pthread_join");
        }
    }

    // Free allocated memory
    free(threads);
    free(task_array);
    free(args);

    exit(EXIT_SUCCESS);
}

void ReadArguments(int argc, char **argv, int *threads_count, int *arraySize)
{
    *arraySize = DEFAULT_ARRAYSIZE;
    *threads_count = DEFAULT_THREADS_COUNT;

    //The program takes 2 input parameters: n,k. where n is the number of processing posix threads and k is the task array size
    if(argc >= 3)
    {
        *threads_count = atoi(argv[1]);
        *arraySize = atoi(argv[2]);

        if(*arraySize <= 0 || *threads_count <= 0)
        {
            printf("Invalid value for array size or threads count");
            exit(EXIT_FAILURE);
        }
    }
}

void* print_star(void *voidArgs)
{
    printf("*\n");
    return NULL;
}

//processing threads are choosing random array cell number, print its index and exit.
void* thread_process_task(void *voidArgs)
{
    threadArgs_t *args = (threadArgs_t *)voidArgs;
    int index = rand() % args->arraySize;

    printf("Processing index no.: %d\n", index);

    return NULL;
}

//Main thread is waiting for all threads.
void print_array(float *array, int array_size)
{
    printf("[ ");
    
    for(int i = 0; i < array_size; i++)
    {
        printf("%f ", array[i]);
    }

    printf(" ]");
}



