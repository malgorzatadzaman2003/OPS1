#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <math.h>

#define MAXLINE 4096
#define DEFAULT_THREADS_COUNT 100
#define DEFAULT_ARRAYSIZE 10
#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

void ReadArguments(int argc, char **argv, int *threads_count, int *arraySize);
void* print_star(void *voidArgs);
void* thread_process_task(void *args);
void print_array(float *array, int size);
void print_results_array(float *results_array, int threads_count);

typedef unsigned int UINT;
typedef struct timespec timespec_t;

typedef struct threadArgs
{
    int threads_count;
    int arraySize;
    float *task;
    float *results;
    pthread_t tid;
    pthread_mutex_t *mutexes;        // Mutexes for each task cell
    int *completed;                 // Array indicating if a task is completed
    int *remaining_tasks;           // Shared counter for remaining tasks
    pthread_mutex_t *remaining_mutex; // Mutex for accessing the remaining_tasks counter
}threadArgs_t;

void msleep(UINT milisec)
{
    time_t sec = (int)(milisec / 1000);
    milisec = milisec - (sec * 1000);

    timespec_t req = {0};
    req.tv_sec = sec;
    req.tv_nsec = milisec * 1000000L;

    if (nanosleep(&req, &req))
    {
        ERR("nanosleep");
    }
}

int main(int argc, char **argv)
{
    int arraySize, threads_count, *completed, remaining_tasks;
    float *task_array, *results_array;
    pthread_t *threads;
    threadArgs_t *args;
    pthread_mutex_t *mutexes;
    pthread_mutex_t remaining_mutex;

    ReadArguments(argc, argv, &threads_count, &arraySize); //reading the input

    //allocate memory 
    task_array = (float *)malloc(arraySize * sizeof(float));
    results_array = (float *)malloc(arraySize * sizeof(float));
    completed = (int *)calloc(arraySize, sizeof(int));  // Track if the task is completed
    mutexes = (pthread_mutex_t *)malloc(arraySize * sizeof(pthread_mutex_t));
    if (!task_array || !results_array || !completed || !mutexes) 
    {
        ERR("malloc/calloc");
    }

    remaining_tasks = arraySize;

    // Main thread is filling the task array and prints it
    for (int i = 0; i < arraySize; i++) 
    {
        task_array[i] = (rand() % 60) + 1.0;
    }

    // Initialize the mutexes for each task element before starting any workers threads
    for (int i = 0; i < arraySize; i++) 
    {
        if (pthread_mutex_init(&mutexes[i], NULL)) 
        {
            ERR("pthread_mutex_init");
        }   
    }

    if (pthread_mutex_init(&remaining_mutex, NULL)) 
    {
        ERR("pthread_mutex_init");
    }

    // Allocate memory for the workers threads
    threads = (pthread_t *)malloc(threads_count * sizeof(pthread_t));
    args = (threadArgs_t *)malloc(threads_count * sizeof(threadArgs_t));
    if (!threads || !args) 
    {
        ERR("malloc");
    }

    //create threads_count processing threads 
    for(int i = 0; i < threads_count; i++)
    {
        args[i].threads_count = threads_count;
        args[i].arraySize = arraySize;
        args[i].task = task_array;
        args[i].results = results_array;
        args[i].mutexes = mutexes;
        args[i].completed = completed;
        args[i].remaining_tasks = &remaining_tasks;
        args[i].remaining_mutex = &remaining_mutex;

        if(pthread_create(&threads[i], NULL, thread_process_task, (void *)&args[i]))
        {
            ERR("pthread_create");
        }
    }

    //Main thread is waiting for all threads.
    for(int i = 0; i < threads_count; i++)
    {
        if(pthread_join(threads[i], NULL))
        {
            ERR("pthread_join");
        }
    }

    // Print the task and results arrays
    print_array(task_array, arraySize);
    print_results_array(results_array, arraySize);

    //destroy mutexes
    for(int i = 0; i < threads_count; i++)
    {
        if (pthread_mutex_destroy(&mutexes[i])) 
        {
            ERR("pthread_mutex_destroy");
        }
    }

    if (pthread_mutex_destroy(&remaining_mutex)) 
    {
        ERR("pthread_mutex_destroy");
    }
    
    // Free allocated memory
    free(task_array);
    free(results_array);
    free(completed);
    free(mutexes);
    free(threads);
    free(args);

    exit(EXIT_SUCCESS);
}

void ReadArguments(int argc, char **argv, int *threads_count, int *arraySize)
{
    *arraySize = DEFAULT_ARRAYSIZE;
    *threads_count = DEFAULT_THREADS_COUNT;

    //The program takes 2 input parameters: n,k. where n is the number of processing posix threads and k is the task array size
    if(argc >= 3)
    {
        *threads_count = atoi(argv[1]);
        *arraySize = atoi(argv[2]);

        if(*arraySize <= 0 || *threads_count <= 0)
        {
            printf("Invalid value for array size or threads count");
            exit(EXIT_FAILURE);
        }
    }
}

void* print_star(void *voidArgs)
{
    printf("*\n");
    return NULL;
}

//Each processing thread is calculating the square root of random array cell and stores the result in result array, prints: “sqrt(a) = b” (b is a result, a is an input) and then sleeps for 100ms. 
void* thread_process_task(void *voidArgs)
{
    threadArgs_t *args = (threadArgs_t *)voidArgs;

    while (1)
    {
        // Check remaining tasks
        pthread_mutex_lock(args->remaining_mutex);
        if (*args->remaining_tasks <= 0) 
        {
            pthread_mutex_unlock(args->remaining_mutex);
            break; // Exit loop if no tasks remain
        }
        pthread_mutex_unlock(args->remaining_mutex);

        // Pick a random task
        int index = rand() % args->arraySize;

        // Lock the mutex for the selected task
        pthread_mutex_lock(&args->mutexes[index]);

        // If the task is not completed, process it
        if (args->completed[index] == 0) 
        {
            args->results[index] = sqrt(args->task[index]);
            printf("Thread %ld: sqrt(%f) = %f at index %d\n", pthread_self(), args->task[index], args->results[index], index);
            args->completed[index] = 1;

            // Decrement the remaining tasks counter
            pthread_mutex_lock(args->remaining_mutex);
            (*args->remaining_tasks)--;
            pthread_mutex_unlock(args->remaining_mutex);
        }

        pthread_mutex_unlock(&args->mutexes[index]);

        msleep(100); // Simulate processing delay
    }

    return NULL;
}


//Main thread is waiting for all threads.
void print_array(float *task_array, int array_size)
{
    // Print the task array
    printf("Task Array: [ ");
    
    for(int i = 0; i < array_size; i++)
    {
        printf("%f ", task_array[i]);
    }

    printf(" ]\n");
}

//Main thread is waiting for all threads.
void print_results_array(float *results_array, int array_size)
{
    // Print the task array
    printf("Results Array: [ ");
    
    for(int i = 0; i < array_size; i++)
    {
        printf("%f ", results_array[i]);
    }

    printf(" ]\n");
}



