#define _XOPEN_SOURCE 500
#define _GNU_SOURCE

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>
#include <ctype.h>

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

void usage(char* name)
{
    fprintf(stderr, "USAGE: %s path\n", name);
    exit(EXIT_FAILURE);
}

void walk1(const char* path)
{
    printf("Walk\n");
}

int interface_stage() 
{
    printf("Enter a command (A. write, B. show, C. walk, D. exit): ");
    char command[16];
    if (scanf("%15s", command) == -1) {
        ERR("scanf");
    }

    char path[256];
    if (strcasecmp(command, "D") == 0) {  // Exit command
        return 0;
    }

    printf("Enter path: ");
    if (scanf("%255s", path) == -1) {
        ERR("scanf");
    }

    struct stat pathstat;
    if (lstat(path, &pathstat) == -1) {  // Check if the file or directory exists
        perror("Invalid path");
        return 1;
    }

    if (strcasecmp(command, "A") == 0) {  // Write command
        write_stage2(path);
    } else if (strcasecmp(command, "B") == 0) {  // Show command
        show_stage3(path);
    } else if (strcasecmp(command, "C") == 0) {  // Walk command
        walk_stage(path);
    } else {
        fprintf(stderr, "Unknown command!\n");
        return 1;
    }

    return 1;
}

void write_stage2(const char* path)
{
    struct stat pathstat;

    if (lstat(path, &pathstat) == -1) 
    {  // Check if the file or directory exists
        ERR("lstat");
    }

    if(!S_ISREG(pathstat.st_mode))
    {
        ERR("S_ISREG");
    }
    
    // Remove the file if it exists
    if (unlink(path) == -1) 
    {  
        ERR("unlink");
    }

    int fd_out = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);  // Create or truncate the file
    if (fd_out == -1) 
    {
        ERR("open");
    }

    printf("Enter text (empty line to finish):\n");

    // Clear the input buffer
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF);

    char buffer[256];

    while (fgets(buffer, sizeof(buffer), stdin)) 
    {  // Read lines from the user
        if (buffer[0] == '\n') break;  // Stop on empty line

        for (int i = 0; buffer[i]; i++) 
        {
            buffer[i] = toupper((unsigned char)buffer[i]);  // Convert to uppercase
        }

        if (write(fd_out, buffer, strlen(buffer)) == -1) 
        {  
            ERR("write");
        }
    }

    if (close(fd_out) == -1) {  // Close the file
        ERR("close");
    }
    
}

void show_stage3(const char* path) {
    struct stat pathstat;

    if (lstat(path, &pathstat) == -1) {
        ERR("lstat");
    }

    if (S_ISDIR(pathstat.st_mode)) {  // Directory case
        DIR* dir = opendir(path);
        if (!dir) {
            ERR("opendir");
        }

        struct dirent* entry;
        while ((entry = readdir(dir))) {  // List directory entries
            printf("%s\n", entry->d_name);
        }

        if (closedir(dir) == -1) {
            ERR("closedir");
        }
    } else if (S_ISREG(pathstat.st_mode)) {  // Regular file case
        int fd = open(path, O_RDONLY);
        if (fd == -1) {
            ERR("open");
        }

        printf("Contents of the file:\n");
        char buffer[256];
        ssize_t bytes;
        while ((bytes = read(fd, buffer, sizeof(buffer))) > 0) {  // Read file contents
            if (write(STDOUT_FILENO, buffer, bytes) == -1) {
                close(fd);
                ERR("write");
            }
        }

        if (bytes == -1) {
            close(fd);
            ERR("read");
        }

        printf("\nSize: %ld bytes\n", pathstat.st_size);
        printf("User ID: %d\n", pathstat.st_uid);
        printf("Group ID: %d\n", pathstat.st_gid);

        if (close(fd) == -1) {
            ERR("close");
        }
    } else {
        fprintf(stderr, "Unknown file type!\n");
    }
}

int walk_callback(const char* fpath, const struct stat* sb, int typeflag, struct FTW* ftwbuf) 
{
    for (int i = 0; i < ftwbuf->level; i++) 
    {
        printf(" ");
    }

    if (typeflag == FTW_D) {  // Directory
        printf("+%s\n", fpath + ftwbuf->base);
    } else if (typeflag == FTW_F) {  // Regular file
        printf(" %s\n", fpath + ftwbuf->base);
    }

    return 0;  // Continue walking
}

void walk_stage(const char* path) 
{
    if (nftw(path, walk_callback, 10, FTW_PHYS) == -1) {  // Recursively walk directory
        ERR("nftw");
    }
}

int main(int argc, char** argv) 
{ 

    interface_stage();
    return 0;
}
