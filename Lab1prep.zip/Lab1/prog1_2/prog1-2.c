#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

#define MAX_PATH 101

void scan_dir()
{
    DIR* dirp;
    struct dirent *dp;
    struct stat filestat;
    int dirs = 0, files = 0, links = 0, others = 0;

    if((dirp = opendir(".")) == NULL)
    {
        ERR("opendir");
    }

    do
    {
        errno = 0;
        if((dp = readdir(dirp)) != NULL)
        {
            if(lstat(dp->d_name, &filestat))
            {
                ERR("lstat");
            }

            if(S_ISDIR(filestat.st_mode))
            {
                dirs++;
            }
            else if(S_ISREG(filestat.st_mode))
            {
                files++;
            }
            else if(S_ISLNK(filestat.st_mode))
            {
                links++;
            }
            else 
            {
                others++;
            }
        }
    }while(dp != NULL);

    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }

    printf("Number of:\n (a) Directories: %d \n (b) Regular files: %d \n (c) Links: %d \n (d) Others: %d \n", dirs, files, links, others);
}

int main(int argc, char **argv)
{
    char path[MAX_PATH];
    
    if(getcwd(path, MAX_PATH) == NULL)
    {
        ERR("getcwd");
    }

    for(int i = 1; i < argc; i++)
    {
        printf("Processing argument: '%s'\n", argv[i]);
        
        if(chdir(argv[i]))
        {
            ERR("chdir");
        }

        printf("Your changed directory - %s:\n", argv[i]);

        scan_dir();

        if(chdir(path))
        {
            ERR("chdir");
        }
    }

    return EXIT_SUCCESS;
}