#define _XOPEN_SOURCE 500
#define _GNU_SOURCE

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>
#include <ctype.h>

#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

#define MAX_GROUPS 20

int groups_count[MAX_GROUPS + 1];

void usage(char* name)
{
    fprintf(stderr, "USAGE: %s path\n", name);
    exit(EXIT_FAILURE);
}

void get_groups_count(const char* dirpath, int counts[MAX_GROUPS + 1]) 
{ 
    DIR* dirp;
    struct dirent *dp;
    struct stat filestat;

    if((dirp = opendir(dirpath)) == NULL)
    {
        ERR("opendir");
    }

    do
    {
        errno = 0;
        if((dp = readdir(dirp)) != NULL)
        {
            char filepath[PATH_MAX];
            snprintf(filepath, sizeof(filepath), "%s/%s", dirpath, dp->d_name);

            if(lstat(filepath, &filestat))
            {
                perror("lstat");
                continue;
            }

            if(S_ISLNK(filestat.st_mode))
            {
                printf("%s: Link encountered\n", dp->d_name);
                continue;
            }

            if(strncmp(dp->d_name, "grupa", 5) == 0) //checks if first 5 characters are the same
            {
                int group_num = atoi(dp->d_name + 5);
                if(group_num < 0 || group_num > MAX_GROUPS)
                {
                    continue;
                }

                FILE* fp = fopen(filepath, "r");

                if(!fp)
                {
                    perror("fopen");
                    continue;
                }

                int students_count;

                if(fscanf(fp, "%d", &students_count) != 1)
                {
                    fprintf(stderr, "Invalid file format: %s\n", dp->d_name);
                    fclose(fp);
                    continue;
                }

                if(fclose(fp))
                {
                    perror("fclose");
                    continue;
                }

                counts[group_num] = students_count;

                if(students_count > 0)
                {
                    printf("Grupa %d zawiera %d studentów\n", group_num, students_count);
                }
                else
                {
                    printf("%s: Link encountered\n", dp->d_name);
                    continue;
                }
            }
        }
    }while(dp != NULL);

    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }
}

void process_file(const char* filepath, int group_count) 
{ 
    int fd_in, fd_out;
    struct iovec* iov_in = NULL;
    struct iovec* iov_out = NULL;
    char new_filepath[PATH_MAX];

    if((fd_in = open(filepath, O_RDONLY)) == -1)
    {
        ERR("open");
    }

    //allocating memory for input and output iovec structures
    iov_in = calloc(group_count, sizeof(struct iovec));
    iov_out = calloc(group_count, sizeof(struct iovec));

    if(!iov_in || !iov_out)
    {
        if(close(fd_in) == -1)
        {
            ERR("close");
        }

        free(iov_in);
        free(iov_out);

        ERR("calloc");
    }

    //Allocate buffers for each student's grade
    for(int i = 0; i < group_count; i++)
    {
        iov_in[i].iov_base = malloc(sizeof(int));
        iov_in[i].iov_len = sizeof(int);

        iov_out[i].iov_base = malloc(sizeof(int));
        iov_out[i].iov_len = sizeof(int);

        if(!iov_in[i].iov_base || !iov_out[i].iov_base)
        {
            if(close(fd_in) == -1)
            {
                ERR("close");
            }

            for(int j = 0; j < i; j++)
            {
                free(iov_in[j].iov_base);
                free(iov_out[j].iov_base);
            }

            free(iov_in);
            free(iov_out);

            ERR("malloc");
        }
    }

    //Read grades 
    ssize_t bytes_read = readv(fd_in, iov_in, group_count);
    if(bytes_read == -1)
    {
        if(close(fd_in) == -1)
        {
            ERR("close");
        }

        for(int i = 0; i < group_count; i++)
        {
            free(iov_in[i].iov_base);
            free(iov_out[i].iov_base);
        }

        free(iov_in);
        free(iov_out);

        ERR("readv");
    }
    
    printf("Grades for file: %s\n", filepath);
    //Print and modify grades 
    for(int i = 0; i < group_count; i++)
    {
        if (bytes_read < (i + 1) * sizeof(int)) 
        {
            fprintf(stderr, "Incomplete data for student %d\n", i);
            *(int*)iov_in[i].iov_base = 0; // Default to 0 if data is missing
        }
        int* grade = (int*)iov_in[i].iov_base;
        printf("Student %d: %dpkt\n", i, *grade);
        *(int*)iov_out[i].iov_base = *grade + 1;
    }

    //Construct new file name
    if (strstr(filepath, "_new") == NULL) 
    {
        snprintf(new_filepath, sizeof(new_filepath), "%s_new", filepath);
    } 
    else 
    {
        snprintf(new_filepath, sizeof(new_filepath), "%s", filepath); // Do not modify
    }


    if((fd_out = open(new_filepath, O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1)
    {
        if(close(fd_in) == -1)
        {
            ERR("close");
        }

        for(int i = 0; i < group_count; i++)
        {
            free(iov_in[i].iov_base);
            free(iov_out[i].iov_base);
        }

        free(iov_in);
        free(iov_out);

        ERR("open");
    }

    ssize_t bytes_written = writev(fd_out, iov_out, group_count);
    if(bytes_written == -1)
    {
        ERR("writev");
    }

    if(close(fd_in) == -1)
    {
        ERR("close");
    }

    if(close(fd_out) == -1)
    {
        ERR("close");
    }

    for(int i = 0; i < group_count; i++)
    {
        free(iov_in[i].iov_base);
        free(iov_out[i].iov_base);
    }

    free(iov_in);
    free(iov_out);

    printf("Modified grades written to: %s\n", new_filepath);
}

// Callback function for nftw
int process_file_nftw(const char *filepath, const struct stat *sb, int typeflag, struct FTW *ftwbuf)
{
    // Skip symbolic links
    if (typeflag == FTW_SL) 
    {
        printf("%s: Link encountered\n", filepath);
        return 0; // Continue processing
    }

    // Check if it is a regular file
    if (typeflag == FTW_F) 
    {
        // Extract filename
        const char *filename = filepath + ftwbuf->base;

        // Validate the format: zMgN
        if (filename[0] == 'z' && isdigit(filename[1])) 
        {
            const char *gPos = strchr(filename, 'g');
            if (gPos != NULL && gPos > filename + 1 && isdigit(*(gPos + 1))) 
            {
                // Extract group and task numbers
                int group = atoi(gPos + 1);
                int task = atoi(filename + 1);

                printf("Grupa %d, zadanie %d:\n", group, task);

                // Example group count for processing (adjust as needed)
                int group_count = groups_count[group];
                if (group_count <= 0) 
                {
                    printf("Invalid or missing group count for group %d\n", group);
                    return 0;
                }

                // Process the file
                process_file(filepath, group_count);
            }
        }
    }
    return 0; // Continue processing
}

// Main batch processing function
void batch_process(const char *dirpath)
{
    printf("Starting batch processing...\n");

    // Use nftw to traverse the directory tree
    if (nftw(dirpath, process_file_nftw, 20, FTW_PHYS) == -1) 
    {
        ERR("nftw");
    }

    printf("Batch processing completed.\n");
}


int main(int argc, char** argv) 
{ 
    if(argc != 2)
    {
        usage(argv[0]);
    }

    const char *const path = argv[1];
    struct stat pathstat;

    if(lstat(path, &pathstat))
    {
        ERR("lstat");
    }

    printf("Enter one of the following commands(groups, process, batch): ");
    char command[16];

    if(scanf("%15s", command) == -1)
    {
        ERR("scanf");
    }

    if(strcmp(command,"groups") == 0)
    {
        if(!S_ISDIR(pathstat.st_mode))
        {
            fprintf(stderr, "Not a directory!\n");
            exit(EXIT_FAILURE);
        }
        get_groups_count(path, groups_count);
    }
    else if(strcmp(command,"process") == 0)
    {
        if(!S_ISREG(pathstat.st_mode))
        {
            fprintf(stderr, "Not a file!\n");
            exit(EXIT_FAILURE);
        }

        int group_count;

        printf("Please give me the number of groups in the file: ");
        if (scanf("%d", &group_count) != 1 || group_count < 1 || group_count > MAX_GROUPS) 
        {
            fprintf(stderr, "Invalid group count\n");
            exit(EXIT_FAILURE);
        }

        process_file(path, group_count);
    }
    else if(strcmp(command,"batch") == 0)
    {
        if(!S_ISDIR(pathstat.st_mode))
        {
            fprintf(stderr, "Not a directory!\n");
            exit(EXIT_FAILURE);
        }
        batch_process(path);
    }
    else
    {
        fprintf(stderr, "Unknown command!\n");
        exit(EXIT_FAILURE);
    }

    return EXIT_SUCCESS; 
}
