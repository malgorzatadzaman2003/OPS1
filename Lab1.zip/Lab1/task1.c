#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <dirent.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>


#define ERR(source) (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), exit(EXIT_FAILURE))

void usage(const char *const pname, const ssize_t bytes)
{
    fprintf(stderr, "USAGE:%s path %zu\n", pname, bytes);
    exit(EXIT_FAILURE);
}

void list_objects(const char *path)
{
    DIR* dirp;
    struct dirent *dp;

    if((dirp = opendir(path)) == NULL)
    {
        ERR("opendir");
    }

    printf("Names of objects in %s folder: \n", path);

    do
    {
        errno = 0;
        if((dp = readdir(dirp)) != NULL)
        {
            printf(" %s\n", dp->d_name);
        }
    }while(dp != NULL);

    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }
}

void list_sizes(const char *path)
{
    DIR* dirp;
    struct dirent *dp;
    struct stat filestat;
    off_t total_size = 0;

    if((dirp = opendir(path)) == NULL)
    {
        ERR("opendir");
    }

    printf("Sizes (without names) of objects in the current working folder,: %s\n", path);

    do
    {
        errno = 0;
        if((dp = readdir(dirp)) != NULL)
        {
            char fullpath[PATH_MAX];
            snprintf(fullpath, sizeof(fullpath), "%s/%s", path, dp->d_name);

            if(lstat(fullpath, &filestat))
            {
                ERR("lstat");
            }

            printf("%ld bytes\n", filestat.st_size);
            total_size += filestat.st_size;
        }
    }while(dp != NULL);

    printf("Total size of all objects: %ld bytes\n", total_size);

    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }
}

void check_folder_size(const char *path, off_t limit_bytes)
{
    DIR* dirp;
    struct dirent *dp;
    struct stat filestat;
    off_t total_size = 0;

    if((dirp = opendir(path)) == NULL)
    {
        ERR("opendir");
    }

    do
    {
        errno = 0;
        if((dp = readdir(dirp)) != NULL)
        {
            char fullpath[PATH_MAX];
            snprintf(fullpath, sizeof(fullpath), "%s/%s", path, dp->d_name);

            if(lstat(fullpath, &filestat))
            {
                ERR("lstat");
            }

            total_size += filestat.st_size;
        }
    }while(dp != NULL);

    if(total_size > limit_bytes)
    {
        printf("%s\n", path);
    }

    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }
}

int main(const int argc, const char *const *const argv)
{
    ssize_t bytes = 0;

    if(argc < 3 || argc % 2 != 1)
    {
        usage(argv[0], bytes);
    }

    for (int i = 1; i < argc; i += 2) 
    {
        const char *path = argv[i];
        off_t limit_bytes = atol(argv[i + 1]);
        check_folder_size(path, limit_bytes);
    }

}

/* 
//part without path

void list_objects()
{
    DIR* dirp;
    struct dirent *dp;
    char cwd[PATH_MAX];
    const char *curr_folder = getcwd(cwd, sizeof(cwd));

    if((dirp = opendir(curr_folder)) == NULL)
    {
        ERR("opendir");
    }

    printf("Names of objects in current working folder: %s\n", curr_folder);

    do
    {
        errno = 0;
        if((dp = readdir(dirp)) != NULL)
        {
            printf(" %s\n", dp->d_name);
        }
    }while(dp != NULL);

    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }
}

void list_sizes()
{
    DIR* dirp;
    struct dirent *dp;
    struct stat filestat;
    char cwd[PATH_MAX];
    const char *curr_folder = getcwd(cwd, sizeof(cwd));
    int total_size = 0;

    if((dirp = opendir(curr_folder)) == NULL)
    {
        ERR("opendir");
    }

    printf("Sizes (without names) of objects in the current working folder,: %s\n", curr_folder);

    do
    {
        errno = 0;
        if((dp = readdir(dirp)) != NULL)
        {
            if(lstat(dp->d_name, &filestat))
            {
                ERR("lstat");
            }

            printf("%ld bytes\n", filestat.st_size);
            total_size += filestat.st_size;
        }
    }while(dp != NULL);

    printf("Total size of all objects: %d bytes\n", total_size);

    if(errno != 0)
    {
        ERR("readdir");
    }

    if(closedir(dirp))
    {
        ERR("closedir");
    }
}
*/